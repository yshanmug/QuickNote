package com.yuva.notetakingapp.repository

import com.yuva.notetakingapp.AllNotes
import com.yuva.notetakingapp.Note
import com.yuva.notetakingapp.NoteTakingDao
import com.yuva.notetakingapp.ToDoItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class NoteRepositoryImp @Inject constructor(private val noteDao: NoteTakingDao): NoteRepository {
    override val allNotesWithToDo: Flow<List<AllNotes>> = noteDao.getAllNotesWithToDo()
    override val allNotes: Flow<List<Note>> = noteDao.getAllNotes()

//    override val allToDoItems: Flow<List<ToDoItem>> = noteDao.getAllToDoItems()
    override suspend fun insert(note: Note): Long {
        return noteDao.insertNote(note)
    }

     override suspend fun insertToDoItem(toDoItem: ToDoItem) {
        noteDao.insertToDoItem(toDoItem)
    }


    override suspend fun update(note: Note)
    {
        noteDao.updateNote(note)
    }

    override suspend fun delete(noteId: Int) {
        noteDao.deleteNote(noteId)
        noteDao.deleteToDoItem(noteId)
    }

}