package com.yuva.notetakingapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import org.intellij.lang.annotations.JdkConstants.CursorType



@Dao
interface NoteTakingDao {
//    @Insert(onConflict = OnConflictStrategy.IGNORE)
    @Insert
    suspend fun insertNote(note: Note)  : (Long)

    @Insert
    suspend fun insertToDoItem(toDoItem: ToDoItem)

    @Query("delete from Note where id = :noteId")
    suspend fun deleteNote(noteId: Int)

    @Query("delete from ToDoItem where noteId = :noteId")
    suspend fun deleteToDoItem(noteId: Int)

    @Query("select * from Note order by id desc")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT  Note.id, Note.title, Note.description, ToDoItem.toDoItem, ToDoItem.isChecked FROM Note LEFT JOIN ToDoItem ON Note.id = ToDoItem.noteId ")
    fun getAllNotesWithToDo(): Flow<List<AllNotes>>

    @Update
    suspend fun updateNote(note: Note)


//    @Query("select * from Note ORDER BY title ASC")
//    suspend fun sortNote()

}

