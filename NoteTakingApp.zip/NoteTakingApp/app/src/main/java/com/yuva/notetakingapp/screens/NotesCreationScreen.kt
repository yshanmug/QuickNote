package com.yuva.notetakingapp.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.ZeroCornerSize
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuva.notetakingapp.Note



//faeeeeee
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun NoteScreen(
    note: Note,
    isToDoList: Boolean,
    onTitleValueChange: (String) -> Unit,
    onDescriptionValueChange: (String) -> Unit

) {


    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
//        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = Modifier
//            .fillMaxWidth()
            .fillMaxSize()
            .padding(horizontal = 10.dp, vertical = 20.dp)
//            .imePadding()

    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 0.dp, bottom = 0.dp)
        ) {
            IconButton(onClick = {

            }) {
                Icon(
                    Icons.Filled.ArrowBack,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    contentDescription = "back"
                )
            }
//            IconButton(onClick = {
////                notesViewModel.deleteNote(Note(id = 0, title, description))
//            }) {
//                Icon(Icons.Filled.Delete, tint = Color.Black, contentDescription = "Delete")
//            }
        }


//        Column(
////            horizontalAlignment = Alignment.CenterHorizontally,
//            modifier = Modifier
//                .fillMaxSize()
//                .imePadding()
////                .verticalScroll(),
//        )
//        {
            TextField(
                modifier = Modifier

                    .fillMaxWidth()
                    .padding(vertical = 0.dp)
                    ,
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = MaterialTheme.colorScheme.onPrimary,
                    focusedTextColor = MaterialTheme.colorScheme.onPrimary,
                    unfocusedTextColor = MaterialTheme.colorScheme.onPrimary,


                    ),
                value = note.title,
                onValueChange = {

                    onTitleValueChange(it)
                },
                placeholder = {
                    Text(
                        "Title..",
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onTertiary
                    )
                },
                textStyle = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                ),
                shape = MaterialTheme.shapes.small.copy(bottomEnd = ZeroCornerSize, bottomStart = ZeroCornerSize)


                )

//            Spacer(modifier = Modifier.height(1.dp))
        if(isToDoList)
        {
            Checkbox( checked = true, onCheckedChange = {true } )





        }
        else
        {
            TextField(
                value = note.description,
                onValueChange = {
                    onDescriptionValueChange(it)
                },
                placeholder = {
                    Text(
                        "Description..",
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onTertiary
                    )
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 0.dp),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = MaterialTheme.colorScheme.onPrimary,
                    unfocusedTrailingIconColor = Color.Transparent,
                    focusedTextColor = MaterialTheme.colorScheme.onPrimary,
                    unfocusedTextColor = MaterialTheme.colorScheme.onPrimary,
                ),
                maxLines = Int.MAX_VALUE,
                keyboardOptions = KeyboardOptions(),
                shape = MaterialTheme.shapes.small.copy(bottomEnd = ZeroCornerSize, bottomStart = ZeroCornerSize)

            )




        }




//        }


    }
}


//@Preview()
//@Composable
//fun RegisterUserPreview(){
//    RegisterUserScreen(UserResponse("Success", onClick = {} ))
//}


@Preview(showBackground = true)
@Composable
fun NoteScreenPreview()
{
        // Sample data for the preview
        val sampleNote = Note(
            title = "Sample Title",
            description = "Sample Description"
        )

        NoteScreen(
            note = sampleNote,
            isToDoList = false,
            onTitleValueChange = {},
            onDescriptionValueChange = {}
        )

}



//
//@Composable
//fun NotesCreationScreen(notesViewModel: NotesViewModel = hiltViewModel(), backButtonClicked: () -> Unit)
//{
//    var title by remember { mutableStateOf("") }
//    var description by remember { mutableStateOf("") }
//Column(
//                modifier = Modifier.padding(16.dp).fillMaxSize(),
//                verticalArrangement = Arrangement.spacedBy(8.dp)
//            ) {
//                Text("Add a new note", style = MaterialTheme.typography.bodyMedium)
//                TextField(
//                    value = title,
//                    onValueChange = { title = it },
//                    label = { Text("Title") }
//                )
//                TextField(
//                    value = description,
//                    onValueChange = { description = it },
//                    label = { Text("Description") }
//                )
//                Button(
//                    onClick = {
//                        if (title.isNotEmpty() && description.isNotEmpty()) {
//                            notesViewModel.insertNote(
//                                Note(
////                                id = 0, // ID will be autogenerated if using Room
//                                    title = title,
//                                    description = description
//                                )
//                            )
//                            title = ""
//                            description = ""
////                            showDialog = false
//                        }
//                    },
//                    modifier = Modifier.align(Alignment.End),
//                    colors = ButtonDefaults.buttonColors(contentColor = Color.White)
//                ) {
//                    Text("Add Note")
//                }
//
//
//            }
//        }


//coralTheme


//package com.yuva.notetakingapp.screens
//
//import android.provider.CalendarContract
//import android.util.Config.LOGD
//import android.util.Log
//import androidx.compose.foundation.background
//import androidx.compose.foundation.border
//import androidx.compose.foundation.clickable
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
//import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
//import androidx.compose.foundation.lazy.staggeredgrid.items
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.Add
//import androidx.compose.material.icons.filled.Delete
//import androidx.compose.material3.Button
//import androidx.compose.material3.ButtonDefaults
//import androidx.compose.material3.ExperimentalMaterial3Api
//import androidx.compose.material3.FloatingActionButton
//import androidx.compose.material3.Icon
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.material3.Scaffold
//import androidx.compose.material3.Surface
//import androidx.compose.material3.Text
//import androidx.compose.material3.TextField
//import androidx.compose.material3.TopAppBar
//import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.collectAsState
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.remember
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.tooling.preview.Preview
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.compose.ui.window.Dialog
//import androidx.hilt.navigation.compose.hiltViewModel
//import com.yuva.notetakingapp.Note
//import com.yuva.notetakingapp.viewmodels.NotesViewModel
//
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun ScreenV1(
//    notesViewModel: NotesViewModel = hiltViewModel(),
//    onNewNoteClicked: () -> Unit,
//    onNoteClicked: (Note) -> Unit
//) {
//
//    Scaffold(modifier = Modifier,
////        containerColor = Color(0xFFFFEBEE),
//
//        topBar = {
//            TopAppBar(
//                title = { Text("Welcome to Notes App",color = Color(0xF7E56B78), fontWeight = FontWeight.ExtraBold, fontSize = 25.sp,
//                    ) },
//
//
////                colors = topAppBarColors(containerColor = Color(0xFFd9d2e9))
////                colors = topAppBarColors(containerColor = Color(0xFFC7BAEC))
//                colors = topAppBarColors()
//            )
//        },
//        floatingActionButton = {
//            FloatingActionButton(onClick = { onNewNoteClicked() }, containerColor = Color(0xE1E56B78))
//            {
//                Icon(Icons.Filled.Add, contentDescription = "Add")
//            }
//        }) { innerPadding ->
//
//        val notes by notesViewModel.noteList.collectAsState()
//        Log.d("notes", notes.toString())
//        Column(
//            modifier = Modifier
//                .padding(innerPadding)
//                .padding(6.dp)
////                .padding(horizontal = 6.dp)
//
//            ,
////            verticalArrangement = Arrangement.spacedBy(1.dp),
////            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//
//            LazyVerticalStaggeredGrid(
//                columns = StaggeredGridCells.Fixed(2),
//                verticalItemSpacing = 6.dp,
//                horizontalArrangement = Arrangement.spacedBy(6.dp),
//                modifier = Modifier
//            )
//            {
//                items(notes, key = { it.id }) { note ->
//                    Column(
//                        modifier = Modifier
//                            .fillMaxWidth()
//
//                            .clip(RoundedCornerShape(10.dp))
//                            .border(0.5.dp, Color(0xFFE56B78), RoundedCornerShape(10.dp))
//                            .background(Color(0xFff6f6f6))
//
////                            .background(Color(0xFFf6f6f6))
////                            .background(Color(0xFFf6f6f6))
////
//
//                            .clickable {
//                                onNoteClicked(note)
//                            }
//                            .padding(horizontal = 10.dp, vertical = 8.dp)
//
//                            ,
//                    ) {
//                        Row(
//                            verticalAlignment = Alignment.CenterVertically,
//                            horizontalArrangement = Arrangement.SpaceBetween,
//                            modifier = Modifier
//                                .fillMaxWidth()
//
//                        ) {
//                            Text(
//                                text = note.title,
//                                fontSize = 20.sp,
//                                color = Color(0xF7E56B78) ,
//                                textAlign = TextAlign.Center,
//                                fontWeight = FontWeight.W500
//                            )
//                            IconButton(onClick = { notesViewModel.deleteNote(note) }) {
//                                Icon(
//                                    Icons.Filled.Delete,
//                                    modifier = Modifier.size(20.dp),
//                                    tint = Color(0xB4E56B78),
//                                    contentDescription = "Delete"
//                                )
//                            }
//
//                        }
//                        Text(note.description)
//                    }
//
//                }
//
//            }
//        }
//    }
//}
//
//
//

