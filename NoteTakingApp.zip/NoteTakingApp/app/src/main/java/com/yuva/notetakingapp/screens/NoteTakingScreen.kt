package com.yuva.notetakingapp.screens

import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Arrangement.Start
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.modifier.EmptyMap.set
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.yuva.notetakingapp.Note
import com.yuva.notetakingapp.ToDoItem
import com.yuva.notetakingapp.viewmodels.NotesViewModel
import kotlinx.coroutines.flow.forEach


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteTakingScreen(
    notesViewModel: NotesViewModel = hiltViewModel(),
    note: Note,
    isToDoList: Boolean,
    onBackPressed:(isToDoList: Boolean) -> Unit,
    onTitleValueChange: ( String) -> Unit,
    onDescriptionValueChange: (String) -> Unit,
    onToDoListValueChange: (List<String>) -> Unit,
) {
    val toDoListItems by notesViewModel.toDoListItems.collectAsState()
//    Log.d("ToDoListItemsinNoteScreen", toDoListItems.toList().toString())
    val interactionSource = remember { MutableInteractionSource() }
    val focusRequester = remember { FocusRequester() }


    //    var selectedNotes by remember { mutableStateOf<List<Note>>(emptyList()) }
    //    val toDoListItems by remember {mutableStateOf<List<String>>(emptyList()) }
    BackHandler()
    {
        onBackPressed.invoke(isToDoList)
    }
    val scrollState = rememberScrollState()
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .background(color = MaterialTheme.colorScheme.background)
            .padding(horizontal = 10.dp, vertical = 20.dp)
            .imePadding()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp, bottom = 0.dp)
        ) {
            IconButton(onClick = {
                onBackPressed.invoke(isToDoList)

            }) {
                Icon(
                    Icons.Filled.ArrowBack,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    contentDescription = "back"
                )
            }
        }
        Column(modifier = Modifier.verticalScroll(scrollState))
        {
            TextField(
                modifier = Modifier
                    .padding(vertical = 0.dp)
                    .fillMaxWidth(),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = MaterialTheme.colorScheme.onPrimary,
                    focusedTextColor = MaterialTheme.colorScheme.onPrimary,
                    unfocusedTextColor = MaterialTheme.colorScheme.onPrimary,
                ),
                value = note.title,
                onValueChange = {
                    onTitleValueChange(it)
                },
                placeholder = {
                    Text(
                        "Title..",
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onTertiary
                    )
                },
                textStyle = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                ),


                )

            if (isToDoList) {

                toDoListItems.forEachIndexed{ index, item ->
                    Log.d("ToDoListItemsALLTIME", toDoListItems.toList().toString())
                    DynamicRow(
                        index = index ,
                        toDoItem = item,
                        onDelete = { notesViewModel.deletedToDoItem(index) },
                        onValueChange = {indexValue, it -> notesViewModel.updateToDoItem(indexValue, it) },
                        focusRequester = focusRequester
                    )//
                }
                Log.d("ToDoListItems1", toDoListItems.toList().toString())
                //
                ////
                Row(
                    Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .clickable {
                            notesViewModel.addToDoItem(noteId = 0,
                                toDoText = "", isChecked = false
                            )
//                         focusRequester.requestFocus()

                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp))
                {
                    Icon(
                        Icons.Filled.Add,
                        tint = MaterialTheme.colorScheme.onTertiary,
                        contentDescription = "Clear",
                    )

                    Text(
                        modifier = Modifier
                            .fillMaxWidth(), text = "Add Item",
                        color = MaterialTheme.colorScheme.onTertiary
                    )
                }
            }
            else {
                TextField(
                    value = note.description,
                    onValueChange = {
                        onDescriptionValueChange(it)
                    },
                    placeholder = {
                        Text(
                            "Description..",
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onTertiary
                        )
                    },

                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 0.dp),
                    colors = TextFieldDefaults.textFieldColors(
                        containerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = MaterialTheme.colorScheme.onPrimary,
                        unfocusedTrailingIconColor = Color.Transparent,
                        focusedTextColor = MaterialTheme.colorScheme.onPrimary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    maxLines = Int.MAX_VALUE,
                    keyboardOptions = KeyboardOptions(),
                )

            }


        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicRow(
    index: Int = 0,
    toDoItem: ToDoItem,
    onValueChange: (Int, ToDoItem) -> Unit,
    onDelete: (Int) -> Unit,
    focusRequester: FocusRequester
) {
    val (checkedState, onStateChange) = remember { mutableStateOf(toDoItem.isChecked) }
    Row(
        Modifier
            .fillMaxWidth()
            //            .toggleable(
            //                value = checkedState,
            //                onValueChange = { onStateChange(!checkedState)
            //                                onValueChange(toDoItem.copy(isChecked = !checkedState))},
            //                role = Role.Checkbox
            //            )
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            modifier = Modifier.size(20.dp),
            checked = checkedState,
            onCheckedChange = {
                onStateChange(it)
                onValueChange(index, toDoItem.copy(isChecked = it))
            },
        )
        TextField(
            value = toDoItem.toDoItem,
            onValueChange = {
                onValueChange(index, toDoItem.copy(toDoItem = it))

            },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 0.dp)
                .focusRequester(focusRequester),

            colors = TextFieldDefaults.textFieldColors(
                containerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = MaterialTheme.colorScheme.onSecondary,
                focusedTextColor = MaterialTheme.colorScheme.onSecondary,
                unfocusedTextColor = MaterialTheme.colorScheme.onSecondary,
            ),
            maxLines = Int.MAX_VALUE,
            keyboardOptions = KeyboardOptions.Default,

            textStyle = if (checkedState) {
                TextStyle(textDecoration = TextDecoration.LineThrough) // Strikethrough when checked
            } else {
                TextStyle.Default
            }
        )

        IconButton(onClick = { onDelete(index) })
        {
            Icon(
                Icons.Filled.Clear,
                tint = MaterialTheme.colorScheme.onTertiary,
                contentDescription = "Clear"
            )
        }
    }
}


//@Preview()
//@Composable
//fun RegisterUserPreview(){
//    RegisterUserScreen(UserResponse("Success", onClick = {} ))
//}
