package com.yuva.notetakingapp
import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NoteTakingApp: Application() {
}

