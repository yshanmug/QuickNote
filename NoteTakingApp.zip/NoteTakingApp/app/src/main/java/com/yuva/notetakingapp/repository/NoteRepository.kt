package com.yuva.notetakingapp.repository

import com.yuva.notetakingapp.AllNotes
import com.yuva.notetakingapp.Note
import com.yuva.notetakingapp.ToDoItem
import kotlinx.coroutines.flow.Flow

//interface NoteRepository {
//    suspend fun getNotes(): List<Note>
//}

interface NoteRepository {

    val allNotesWithToDo: Flow<List<AllNotes>>
    val allNotes: Flow<List<Note>>
//    val allToDoItems: Flow<List<ToDoItem>>
    suspend fun insert(note: Note) : Long
    suspend fun insertToDoItem(toDoItem: ToDoItem)
//    suspend fun deleteToDoItem(toDoItem: ToDoItem)
    suspend fun update(note: Note)
    suspend fun delete(noteId: Int)
}