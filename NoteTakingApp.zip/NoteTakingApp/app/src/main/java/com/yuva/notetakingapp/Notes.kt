package com.yuva.notetakingapp

//data class NotesList(
//    val id: Int = 0,
//    val title: String = "",
//    val description: String = "",
//    val notes: List<Note> = emptyList(),
//    val isToDoList: Boolean = false, // Add a flag to differentiate between note types
//    val toDoListItems: List<String> = emptyList(
//))

data class AllNotes(
    val id : Int = 0,
    val title: String? = "",
    val description: String? = null,
    val toDoItem: String? = null,
    val isChecked: Boolean? = false // not needed
//    note type enum class , todoitem list of todoitems
)