﻿package com.yuva.notetakingapp.screens

import android.icu.text.DateFormat
import android.icu.util.Calendar
import android.os.Build
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.annotation.RequiresApi
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.waterfallPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxColors
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.PopupProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.yuva.notetakingapp.Note
import com.yuva.notetakingapp.R
import com.yuva.notetakingapp.ui.theme.ranchoFamily
import com.yuva.notetakingapp.viewmodels.NotesViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.forEach
import kotlinx.coroutines.launch
import java.time.LocalTime


//@RequiresApi(Build.VERSION_CODES.O)
@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ScreenV1(
    notesViewModel: NotesViewModel = hiltViewModel(),
    onNewNoteClicked: (isToDoList: Boolean) -> Unit,
    onNoteClicked: (Note) -> Unit,
    onBackPress: () -> Unit,
    onSortByTimePress: (isAscending: Boolean) -> Unit,
    onSortByTitlePress: (isAscending: Boolean) -> Unit,
//    onToDoListPress: (Boolean ) -> Unit,

) {


    var expanded by remember { mutableStateOf(false) }
    var selectedNotes by remember { mutableStateOf<List<Note>>(emptyList()) }
    val snackBarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var isAscendingByTitle by remember { mutableStateOf(false) }
    var isAscendingByTime by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

//    val checkedState = remember {mutableStateOf(true)}
val toDoListItems by notesViewModel.toDoListItems.collectAsState()
    Log.d("ToDoListItemsScreenV1", toDoListItems.toString())

    BackHandler()
    {
        onBackPress.invoke()

    }

    Scaffold(
        modifier = Modifier,
        containerColor = MaterialTheme.colorScheme.background,

        snackbarHost = {
            SnackbarHost(hostState = snackBarHostState, modifier = Modifier.size(300.dp, 100.dp))
        },


        topBar = {
            TopAppBar(
                title = {
                    GreetingText()
                },
                actions = {
                    IconButton(
                        onClick = {
                            onSortByTitlePress(!isAscendingByTitle)
                            isAscendingByTitle = !isAscendingByTitle
                        },
                        colors =  androidx.compose.material3.IconButtonDefaults.iconButtonColors( contentColor = MaterialTheme.colorScheme.onPrimary),
                        interactionSource = interactionSource,
                      ) {
                        Icon(
                            painter = painterResource(id = R.drawable.sortbyascdsc),
                            contentDescription = "SortByTime", modifier = Modifier.size(25.dp),

                            )

                        Log.d("FlagValue", isAscendingByTitle.toString())
                    }

                    IconButton(onClick = {
                        onSortByTimePress(!isAscendingByTime)
                        isAscendingByTime = !isAscendingByTime
                    },
                        modifier = Modifier
                        ,
                        colors =  androidx.compose.material3.IconButtonDefaults.iconButtonColors( contentColor = MaterialTheme.colorScheme.onPrimary),)

                    {
                        Icon(
                            painter = painterResource(id = R.drawable.sortbytime),
                            contentDescription = "Search", modifier = Modifier.size(25.dp)
                        )

                    }

                    Log.d("FlagValue1", isAscendingByTime.toString())

                    IconButton(onClick = { expanded = true }) {
                        Icon(
                            Icons.Filled.MoreVert,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            contentDescription = "More"
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.secondary)
                                .wrapContentHeight()
                                .width(150.dp),
                            content = {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            "Delete Note",
//                                            fontStyle = FontStyle.Italic,
                                            fontSize = 16.sp,
                                            color = MaterialTheme.colorScheme.onPrimary


                                        )
                                    },
                                    onClick = {
                                        if (selectedNotes.isNotEmpty()) {
                                            selectedNotes.forEach {
                                                notesViewModel.deleteNote(it.id)
                                            }
                                            selectedNotes = emptyList()
                                            expanded = false

                                        } else {
                                            scope.launch {
                                                snackBarHostState.showSnackbar("Please Select a note to delete")

                                            }

                                        }


                                    },

                                    )
                            },
                            properties = PopupProperties(focusable = true),
                            offset = androidx.compose.ui.unit.DpOffset(x = 0.dp, y = 15.dp)
                        )
                    }
                },
                colors = topAppBarColors(MaterialTheme.colorScheme.primary),
                modifier = Modifier,
            )
        },

        bottomBar = {
            BottomAppBar(
                actions = {
                    Checkbox( checked = true, onCheckedChange = {onNewNoteClicked(true)  },
                        modifier = Modifier
                         )
                    Text(text = "To-Do List")
                },

                containerColor = MaterialTheme.colorScheme.background,
                modifier = Modifier,

                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { onNewNoteClicked(false) },
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                    {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = "Add",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        },

//        floatingActionButton = {
//            FloatingActionButton(
//                onClick = { onNewNoteClicked() },
//                containerColor = MaterialTheme.colorScheme.surface
//            )
//            {
//                Icon(
//                    Icons.Filled.Add,
//                    contentDescription = "Add",
//                    tint = MaterialTheme.colorScheme.onSurface
//                )
//            }
//        }
    )
    { innerPadding ->

        val notes by notesViewModel.noteList.collectAsState()
        Log.d("mynotesList", notes.toString())
        if ((notes.isEmpty())) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Take Your First Note...",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    fontStyle = FontStyle.Italic
                )
            }
        } else {

            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    verticalItemSpacing = 8.dp,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                )
                {

                    items(items = notes, key = { it.id!! }, ) { note ->

                        val isSelected = selectedNotes.contains(note)
                        Column(
                            modifier = Modifier
                                .widthIn(min = 0.dp, max = 200.dp)
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.05.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.secondary)
                                .fillMaxWidth()
//                                .aspectRatio(1f)
                                .combinedClickable(
                                    onClick = {
                                        if (selectedNotes.isNotEmpty()) {
                                            selectedNotes = if (isSelected) {
                                                selectedNotes - note
                                            } else {
                                                selectedNotes + note
                                            }
                                        } else {
                                            onNoteClicked(note)
                                        }
                                    },
                                    onLongClick = {
                                        selectedNotes = if (isSelected) {
                                            selectedNotes - note
                                        } else {
                                            selectedNotes + note
                                        }
                                    }
                                )
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                .heightIn(min = 0.dp, max = 200.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            if (note.title.isNotEmpty()) {
                                Text(
                                    text = note.title,
                                    fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSecondary,
                                    textAlign = TextAlign.Start,
                                    fontWeight = FontWeight.W500
                                )
                            }

                            // If the description is present, display it
                            if (note.description.isNotEmpty()) {
                                Log.d("description", note.description)
                                    Text(
                                        text = note.description,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        fontSize = 14.sp,
                                        textAlign = TextAlign.Start
                                    )

                            }
                            else {
                                // If the description is missing, add a Spacer to occupy the space
                                Spacer(modifier = Modifier.height(0.dp)) // Adjust the height based on your layout needs
                            }
                        }

                    }

                }
            }
        }


        Log.d("notes", notes.toString())

    }
}





fun calculateTime(): String {
    if (Build.VERSION.SDK_INT < 26) {
        val currentTime1 = Calendar.getInstance()
        val currentHour = currentTime1.get(Calendar.HOUR_OF_DAY)
        Log.d("CurrentHour", currentHour.toString())

//    val exactTime = DateFormat.getTimeInstance().format(currentTime1)
        val quote = when {
            currentHour < 12 -> "Take Your First Note...!"
            currentHour < 16 -> "Your Afternoon Thoughts and Ideas...!"
            currentHour < 19 -> "Capture Your Evening Reflections...!"
            else -> {
                "Wrap Up the Day with a Thoughtful Note...!"
            }
        }
        return quote


    } else {

        val currentTime = LocalTime.now()
        Log.d("GreetingText:", currentTime.toString())
        val quote = when {
            currentTime < LocalTime.of(12, 0) -> "Take Your First Note...!"
            currentTime < LocalTime.of(16, 0) -> "Your Afternoon Thoughts and Ideas...!"
            currentTime < LocalTime.of(19, 0) -> "Your Afternoon Thoughts and Ideas...!"
            else -> {
                "Wrap Up the Day with a Thoughtful Note...!"
            }
        }
        return quote
    }
}


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun GreetingText() {
    val quote = calculateTime()
    Column {
        TypingTextEffect(text = "{ Journal Me. . . }")
//        Text(
//            text = quote,
//            color = MaterialTheme.colorScheme.onPrimary,
////            fontFamily = ranchoFamily,
//            fontWeight = FontWeight.Normal,
//            fontSize = 20.sp,
//            fontStyle = FontStyle.Italic
//        )
    }
}

@Composable
fun TypingTextEffect(text: String, typingSpeed: Long = 100L) {
    var displayedText by remember { mutableStateOf("") }

    LaunchedEffect(text) {
        displayedText = ""
        text.forEachIndexed { index, char ->
            delay(typingSpeed) // Adjust the delay for typing speed
            displayedText += char
        }// fun DropdownMenu()
    }// {
//
    Text(//
        text = displayedText,// }
        color = MaterialTheme.colorScheme.onPrimary,
        fontWeight = FontWeight.Normal,
        fontSize = 30.sp,//LightTheme
        fontFamily = ranchoFamily,// package com.yuva.notetakingapp.screens
        fontStyle = FontStyle.Normal//
    )
}

//import android.util.Config.LOGD
//import android.util.Log
//import androidx.compose.foundation.background
//import androidx.compose.foundation.border
//import androidx.compose.foundation.clickable
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.Spacer
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.layout.wrapContentHeight
//import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
//import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
//import androidx.compose.foundation.lazy.staggeredgrid.items
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.Add
//import androidx.compose.material.icons.filled.Delete
//import androidx.compose.material3.Button
//import androidx.compose.material3.ButtonDefaults
//import androidx.compose.material3.ExperimentalMaterial3Api
//import androidx.compose.material3.FloatingActionButton
//import androidx.compose.material3.Icon
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.material3.Scaffold
//import androidx.compose.material3.Surface
//import androidx.compose.material3.Text
//import androidx.compose.material3.TextField
//import androidx.compose.material3.TopAppBar
//import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.collectAsState
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.remember
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.draw.clipToBounds
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.tooling.preview.Preview
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.compose.ui.window.Dialog
//import androidx.hilt.navigation.compose.hiltViewModel
//import com.yuva.notetakingapp.Note
//import com.yuva.notetakingapp.viewmodels.NotesViewModel
//
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun ScreenV1(
//    notesViewModel: NotesViewModel = hiltViewModel(),
//    onNewNoteClicked: () -> Unit,
//    onNoteClicked: (Note) -> Unit
//) {
//
//    Scaffold(modifier = Modifier,
//        containerColor = MaterialTheme.colorScheme.background,
//
//        topBar = {
//            TopAppBar(
//                title = { Text("Welcome to Notes App", color = MaterialTheme.colorScheme.onPrimary) },
////                colors = topAppBarColors(containerColor = Color(0xFFd9d2e9))
////                colors = topAppBarColors(containerColor = Color(0xED4CAF50))
//                colors = topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
////                colors =  topAppBarColors(Color(0xAB6173EF))
//
//
//            )
//        },
//        floatingActionButton = {
//            FloatingActionButton(onClick = { onNewNoteClicked() }, containerColor = MaterialTheme.colorScheme.primary)
//            {
//                Icon(Icons.Filled.Add, contentDescription = "Add", tint = MaterialTheme.colorScheme.onPrimary)
//            }
//        }) { innerPadding ->
//
//        val notes by notesViewModel.noteList.collectAsState()
//        Log.d("notes", notes.toString())
//        Column(
//            modifier = Modifier
//                .padding(innerPadding)
//                .padding(10.dp)
//
//
//                ,
//            verticalArrangement = Arrangement.spacedBy(16.dp),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//
//            LazyVerticalStaggeredGrid(
//                columns = StaggeredGridCells.Fixed(2),
//                verticalItemSpacing = 8.dp,
//                horizontalArrangement = Arrangement.spacedBy(8.dp),
//                modifier = Modifier
//            )
//            {
//                items(notes, key = { it.id }) { note ->
//                    Column(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .clip(RoundedCornerShape(10.dp))
//                            .border(0.05.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
////                            .background(Color(0xFFFFEBEE))
////                            .background(Color(0x8D6B4EFF))
////                            .background(Color(0x1B6B4EFF))
//                            .background(MaterialTheme.colorScheme.secondary)
//
//
//
//                            .clickable {
//                                onNoteClicked(note)
//                            }
//                            .padding(horizontal = 10.dp, vertical = 8.dp),
//
//                    ) {
//                        Row(
//                            verticalAlignment = Alignment.CenterVertically,
//                            horizontalArrangement = Arrangement.Absolute.SpaceBetween,
//                            modifier = Modifier
//                                .fillMaxWidth()
//
//                        ) {
//                            Text(
//                                text = note.title,
//                                fontSize = 20.sp,
//                                color = MaterialTheme.colorScheme.onPrimary ,
//                                textAlign = TextAlign.Start,
//                                fontWeight = FontWeight.W500,
//                                modifier = Modifier.weight(1f)
//                            )
//                            IconButton(onClick = { notesViewModel.deleteNote(note) }) {
//                                Icon(
//                                    Icons.Filled.Delete,
//                                    modifier = Modifier.size(20.dp).clipToBounds() // Clip the icon to its bounds
//                                        ,
//                                    tint = MaterialTheme.colorScheme.tertiary,
//                                    contentDescription = "Delete",
//
//
//                                )
//                            }
//
//                        }
////                        Spacer(modifier = Modifier.padding(10.dp))
//                        Text(note.description, color = MaterialTheme.colorScheme.onPrimary, fontSize = 16.sp)
//                    }
//
//                }
//
//            }
//        }
//    }
//}
//
//
//
//
//
//
