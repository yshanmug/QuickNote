package com.yuva.notetakingapp.viewmodels

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yuva.notetakingapp.AllNotes
import com.yuva.notetakingapp.Note
import com.yuva.notetakingapp.ToDoItem
import com.yuva.notetakingapp.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.forEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotesViewModel @Inject constructor(private val noteRepository: NoteRepository) : ViewModel() {
    private var _allNoteList = MutableStateFlow<List<AllNotes>>(emptyList())
    val allNoteList = _allNoteList.asStateFlow()

    private var _noteList = MutableStateFlow<List<Note>>(emptyList())
    val noteList = _noteList.asStateFlow()

    private var _note = MutableStateFlow(Note())
    val note = _note.asStateFlow()

    private var _toDoListItems = MutableStateFlow<List<ToDoItem>>(emptyList())
    val toDoListItems = _toDoListItems.asStateFlow()


    init {
        getNotes()
        getNotesWithToDo()
    }

    private fun getNotes() {
        viewModelScope.launch(Dispatchers.IO) {
            noteRepository.allNotes.collect {
                _noteList.value = it
                Log.d("NotesPrinted", it.toString())
            }
        }
    }

    private fun getNotesWithToDo()
    {
        viewModelScope.launch(Dispatchers.IO){
            noteRepository.allNotesWithToDo.collect{
                _allNoteList.value = it
                Log.d("AllNoteswithTodo", _allNoteList.value.toString())

            }

        }

    }

//    private fun getToDoItems(){
//        viewModelScope.launch(Dispatchers.IO)
//        {
//            noteRepository.allToDoItems.collect{
//                _listOfToDoItems.value = it
//                Log.d("ListFromRepository-ToDoItems", it.toString())
//            }
//        }
//    }




    fun addToDoItem(noteId: Int, toDoText: String, isChecked: Boolean)
    {
       val newItem = ToDoItem(noteId = noteId, toDoItem = toDoText, isChecked = isChecked)
        _toDoListItems.value += newItem
        Log.d("ToDoItems", _toDoListItems.value.toString())
    }

   fun updateToDoItem(index : Int, toDoItem: ToDoItem){
       val toDoList = _toDoListItems.value.toMutableList()
       if(index in toDoList.indices)
       {
           toDoList[index] = toDoItem
           _toDoListItems.value = toDoList
       }
   }

    fun deletedToDoItem(index: Int) {
        val toDoList = _toDoListItems.value.toMutableList()
        if (index in toDoList.indices) {
            toDoList.removeAt(index)
            _toDoListItems.value = toDoList
        }
    }

    fun insertToDoItems( noteId: Int)
    {
        Log.d("isitnull", noteId.toString())
        viewModelScope.launch(Dispatchers.IO)
        {
            _toDoListItems.value.forEach{
                Log.d("currentItem", it.toDoItem)

            }

            _toDoListItems.value.forEach {
                it.noteId = noteId
            }

            _toDoListItems.value.forEach {
                if(it.toDoItem.isNotEmpty()) {
                    Log.d("currentItem", it.toDoItem )
                    noteRepository.insertToDoItem(it)
                }
            }
            _toDoListItems.value = (emptyList())
            Log.d("ToDoListIsEmptied", _toDoListItems.value.toString())
        }
    }

    fun insertNote(isToDoList: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            if(isToDoList)
            {
                var noteId = 0L
                var toDoItems = toDoListItems.value.all { it.toDoItem.isEmpty() }
                Log.d("toDoItemsAnyFilter", toDoItems.toString())
                if((note.value.title.isNotEmpty() && toDoListItems.value.any { it.toDoItem.isNotEmpty() })
                    || (note.value.title.isNotEmpty() ||toDoListItems.value.any { it.toDoItem.isNotEmpty() })
                )
                {
                        if(note.value.id != 0){
                            noteRepository.update(note.value)
                            _note.value.id
                        }
                        else
                        {
                            noteId = noteRepository.insert(note.value)
                        }

                        insertToDoItems(noteId.toInt())

                    _note.value = Note()
                }
                else{

                    _toDoListItems.value= emptyList()

                }


            }
            else
            {
                if ((note.value.title.isNotEmpty() && note.value.description.isNotEmpty())
                    || (note.value.title.isNotEmpty() || note.value.description.isNotEmpty())
                ) {
                    if (note.value.id != 0) {
                        noteRepository.update(note.value)
                        _note.value.id
                    }
                    else{
                        noteRepository.insert(note.value)
                    }
                    _note.value = Note()
                }
            }
       }
    }



//    private fun getToDoItems() {
//        viewModelScope.launch(Dispatchers.IO) {
//            noteRepository.allToDoItems.collect {
//                _toDoListItems.value = it
//                Log.d("ToDoItems", it.toString())
//            }
//        }
//    }




    fun sortNoteByTitle(isAscending: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val notesListForSorting = noteRepository.allNotes.first()
            Log.d("sortNoteByTitle: ", notesListForSorting.toString())
            val allTitleAreEmpty = notesListForSorting.all { it.title.isEmpty() }
//            _noteList.value = notesListForSorting.sortedBy {
            Log.d("isAllNotesEmpty", allTitleAreEmpty.toString())
            _noteList.value =
                if (allTitleAreEmpty) {
                    if (isAscending)
                        notesListForSorting.sortedBy { it.description.lowercase() }
                    else
                        notesListForSorting.sortedByDescending { it.description.lowercase() }

                } else {
                    if (isAscending)
                        notesListForSorting.sortedBy {
                            if (it.title.isEmpty()) {
                                "~"
                            } else {
                                it.title.lowercase()
                            }
                        }
                    else
                        notesListForSorting.sortedByDescending {
                            if (it.title.isEmpty()) {
                                "~"
                            } else {
                                it.title.lowercase()
                            }
                        }

                }
            Log.d("AfterSorted", _noteList.value.toString())
        }

    }

    fun sortByTimeCreated(isAscending: Boolean) {
        viewModelScope.launch(Dispatchers.IO)
        {
            val notesListForSortingByTime = noteRepository.allNotes.first()
            Log.d("sortNoteByTime: ", notesListForSortingByTime.toString())
            if (isAscending)
                _noteList.value = notesListForSortingByTime
            else
                _noteList.value = notesListForSortingByTime.reversed()
        }
    }


    fun setNote(note: Note) {
        _note.value = note
    }

    fun updateTitle( title: String) {
        _note.value = note.value.copy(title = title)
    }

    fun updateDescription(description: String) {
        _note.value = note.value.copy(description = description)
    }


    fun deleteNote(noteId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            noteRepository.delete(noteId)
        }
    }


}