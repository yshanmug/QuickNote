package com.yuva.notetakingapp

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.yuva.notetakingapp.screens.NoteTakingScreen
//import com.yuva.notetakingapp.screens.Screen1
import com.yuva.notetakingapp.screens.ScreenV1
//import com.yuva.notetakingapp.screens.NoteTakingScreen
import com.yuva.notetakingapp.ui.theme.NoteTakingAppTheme
import com.yuva.notetakingapp.viewmodels.NotesViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            onBackPressedDispatcher
            NoteTakingAppTheme {

                val notesViewModel = hiltViewModel<NotesViewModel>()
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "AllNoteScreen") {

//                    composable("splashScreen") {
//                        Box(
//                            modifier = Modifier
//                                .fillMaxSize()
//                                .background(Color(0xff41B06E))
//                        )
//                        {
//                            LaunchedEffect(key1 = "splashScreen", block = {
//                                delay(500)
//                                navController.navigate("AllNoteScreen")
//                            })
//                        }
//                    }


                    composable("AllNoteScreen") {
                        ScreenV1(notesViewModel = notesViewModel,
                            onNewNoteClicked = { isToDoList ->
                                navController.navigate("NoteTakingScreen/$isToDoList")
                            },
//                            changed as it
                            onNoteClicked = { note ->
                                notesViewModel.setNote(note)
                                navController.navigate("NoteTakingScreen/false")  // Here, false means it’s a regular note

                            },
                            onBackPress = {
                                finish()
                            },
                            onSortByTimePress = {isAscendingByTime ->
                                notesViewModel.sortByTimeCreated(isAscendingByTime)
                            },
                            onSortByTitlePress = {isAscendingByTitle ->
                                notesViewModel.sortNoteByTitle(isAscendingByTitle)
                            },

                        )
                    }
                    composable(route = "NoteTakingScreen/{isToDoList}", arguments = listOf(navArgument("isToDoList") {
                        type = NavType.BoolType
                    } ) ) { it ->
                        val isToDo = it.arguments?.getBoolean("isToDoList") ?: false
                        val note by notesViewModel.note.collectAsState()


//                        val localLifeCycleOwner = LocalLifecycleOwner.current
//                        LaunchedEffect(key1 = notesViewModel.currentNoteId) {
//                            localLifeCycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED){
//                                notesViewModel.currentNoteId.collect {
//                                    notesViewModel.insertToDoItems(it.toInt())
//                                    navController.popBackStack()
//                                }
//                            }
//                        }

                        NoteTakingScreen(notesViewModel = notesViewModel, note,
                            isToDoList = isToDo,
                            onTitleValueChange = {
                               title ->
                                notesViewModel.updateTitle(title) },
                            onDescriptionValueChange = {
                                notesViewModel.updateDescription(it) },
                            onBackPressed = {isToDoList ->

                                notesViewModel.insertNote(isToDoList)
                                navController.popBackStack()

                            },
                            onToDoListValueChange = {
//                                notesViewModel.updateToDoListItems(it)
                            }
                        )
                    }
                }
            }
        }
    }


    }



@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

//@Preview(showBackground = true)
//@Composable
//fun GreetingPreview() {
//    NoteTakingAppTheme {
//        Greeting("Android")
//    }
//}

//object ScreenA
//
//data class ScreenB(
//    val noteId: Int = -1
//)


//class TodoRepository(
//    private val noteDao: NoteDao,
//    private val todoItemDao: TodoItemDao
//) {
//    suspend fun saveNoteAndTodoItems(note: Note, todoItems: List<TodoItem>): Long {
//        val noteId = noteDao.insertOrUpdateNote(note)
//        todoItemDao.insertTodoItems(todoItems.map { it.copy(noteId = noteId) })
//        return noteId
//    }
//}
